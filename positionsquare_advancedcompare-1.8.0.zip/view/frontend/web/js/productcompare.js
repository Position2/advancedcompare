define(
    [
    'jquery',
    'compare'
    ], function ($) {
    'use strict';
    $(document).ready(
        function () {
        alert("Compare JS loading");
        }
    );
    }
);