var config = {
  paths: {
    'compare': 'Positionsquare_Advancedcompare/js/compare'
  },
  shim: {
    'compare': {
      deps: ['jquery']
    }
  }
};