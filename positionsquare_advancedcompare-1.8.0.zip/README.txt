Installation process -
1) Create vendor folder "Positionsquare" inside app/code/ folder.
2) Create module folder "Advancedcompare" inside app/code/Positionsquare/ folder.
3) Extract downloaded zip file inside app/code/Positionsquare/Advancedcompare/ folder.